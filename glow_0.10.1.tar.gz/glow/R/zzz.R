.onAttach <- function(libname, pkgname) {
  # nothing for now
}
